package com.thymeleafspringbootapplication.employeemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
